object Brew {
  // Because Brew is an "object", this is a
  // public static void main(...), just like Java.

  // Make it so running "scala ScalaBasics decaf"
  // creates a new instance of the Java class Coffee
  // with name = "decaf" and calls the brew() method 
  // on it.
  def main(args: Array[String]) = {
    // You can call Java stuff transparently from Scala.

  }
}
