/**********************************************************************
 *  N-Body Simulation readme.txt template
 **********************************************************************/


Name:
Login:
Precept:
OS:
Machine (e.g., Dell Latitude, MacBook Pro):
Text editor:
Hours to complete assignment (optional):

/**********************************************************************
 *  If you created your own universe for extra credit, describe it
 *  here and why it is interesting.
 **********************************************************************/


/**********************************************************************
 *  StdAudio survey
 **********************************************************************/
Did you try to add the line to play 2001.mid in your program?

If you tried, were you successful?

If unsuccessful, please describe what happened.

If unsuccessful, please run StdAudio (java StdAudio).  Did you hear
a scale?

/**********************************************************************
 *  List whatever help (if any) you received from lab TAs, preceptors,
 *  classmates, past COS 126 students, or anyone else.
 **********************************************************************/



/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/



/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/


